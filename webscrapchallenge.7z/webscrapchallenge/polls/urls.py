from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('<int:startscrapping>/', views.startscrapping, name='startscrapping'),
    path('<int:startscrapping>/run/', views.run, name='run'),
    path('<int:startscrapping>/result_GE/', views.result_GE, name='result_GE'),
    path('<int:startscrapping>/result_G1/', views.result_G1, name='result_G1'),

]