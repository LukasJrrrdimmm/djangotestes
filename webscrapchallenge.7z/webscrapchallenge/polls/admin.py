from django.contrib import admin
from .models import G1, GE

admin.site.register(G1)
admin.site.register(GE)
