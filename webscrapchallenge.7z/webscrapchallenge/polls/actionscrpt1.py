from .models import G1, GE
from django.utils import timezone as tmz
