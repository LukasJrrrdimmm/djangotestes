from django.db import models
from django.utils import timezone
import datetime

class G1(models.Model):
    title = models.CharField(max_length=500)
    subtitle = models.CharField(max_length=500)
    scrap_time = models.DateTimeField('date scrapped')

    def __str__(self):
        return self.title, self.subtitle

class GE(models.Model):
    title = models.CharField(max_length=500)
    subtitle = models.CharField(max_length=500)
    scrap_time = models.DateTimeField('date scrapped')

    def __str__(self):
        return self.title, self.subtitle

class ScrappedData(models.Model):
    data_g1 = models.ForeignKey(G1, on_delete=models.CASCADE)
    data_ge = models.ForeignKey(GE, on_delete=models.CASCADE)
    startscrap = models.BooleanField(default=False)
# Create your models here.
