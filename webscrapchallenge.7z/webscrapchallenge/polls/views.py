from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import G1, GE

# Create your views here.
def index(request):
    g1_title_subtitle_list = {'title': G1.objects.order_by('-pub_date')[:5],
                              'subtitle': G1.objects.order_by('-pub_date')[:5]}
    ge_title_subtitle_list = {'title':GE.objects.order_by('-pub_date')[:5],
                              'subtitle':GE.objects.order_by('-pub_date')[:5]}
    template = loader.get_template('polls/index.html')
    context = {
        'g1_title_subtitle_list': g1_title_subtitle_list,
        'ge_title_subtitle_list': ge_title_subtitle_list,
    }
    return HttpResponse(template.render(context, request))

def ScrapOrder(request, ):

def g1_results(request, ):