from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import G1, GE, ScrappedData
from .post import ScrapAndPost


# Create your views here.
def index(request):
    return render(request, 'polls/index.html')


def scrapped(request):
    ScrapAndPost()
    template = loader.get_template('polls/scrapped.html')
    return HttpResponseRedirect(template.render(request))


def result_G1(request, data_g1_id):
    data_g1 = get_object_or_404(G1, pk=data_g1_id)
    g1_title_subtitle_list = {
        'title': G1.objects.order_by('-scrap_time')[:5],
        'subtitle': G1.objects.order_by('-scrap_time')[:5]
    }
    context = {
        'g1_title_subtitle_list': g1_title_subtitle_list,
    }
    return HttpResponse(template.render(context, request))


def result_GE(request, data_ge_id):
    data_ge = get_object_or_404(GE, pk=data_ge_id)
    ge_title_subtitle_list = {
        'title': GE.objects.order_by('-scrap_time')[:5],
        'subtitle': GE.objects.order_by('-scrap_time')[:5]
    }
    context = {
        'ge_title_subtitle_list': ge_title_subtitle_list,
    }
    return HttpResponse(template.render(context, request))
