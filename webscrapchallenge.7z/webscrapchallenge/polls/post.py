from .models import GE, G1, ScrappedData
from .actionscrpt1 import StartScrap
import json
from datetime import datetime

def ScrapAndPost():
    data_g1, data_ge = StartScrap()
    aux_a = ""
    aux_b = ""
    for x in data_g1['headers']:
        aux_a += f"({x})"
    for x in data_g1['title']:
        aux_b += f"({x})"
    g1 = G1(
        title= aux_a,
        subtitle=aux_b,
        scrap_time=data_g1['scrapdate']
    )
    aux_a = ""
    aux_b = ""
    for x in data_ge['headers']:
        aux_a += f"({x})"
    for x in data_ge['title']:
        aux_b += f"({x})"
    ge = GE(
        title=aux_a,
        subtitle=aux_b,
        scrap_time=data_g1['scrapdate']
    )
    scraptime = datetime.now()
    aux = scraptime.strftime('%d-%m-%Y %H-%M')
    sd = ScrappedData(startscrap=True)
    g1.save()
    ge.save()
    sd.save()
    with open(f"Json/G1_data({aux}).json", 'w') as outfile:
        json.dump(data_g1, outfile, indent=4, ensure_ascii=False)
    with open(f"Json/GE_data({aux}).json", 'w') as outfile:
        json.dump(data_ge, outfile, indent=4, ensure_ascii=False)




