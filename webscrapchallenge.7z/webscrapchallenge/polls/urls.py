from django.urls import path
from . import views

app_name = 'polls'
urlpatterns = [
    path('', views.index, name='index'),
    path('scrapped/', views.scrapped, name='scrapped'),
    path('result_GE/', views.result_GE, name='result_GE'),
    path('result_G1/', views.result_G1, name='result_G1'),

]