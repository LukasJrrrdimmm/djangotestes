from django.utils import timezone
import requests
from bs4 import BeautifulSoup

def StartScrap():
    data_g1 = requests.get('https://g1.globo.com/')
    soup_g1 = BeautifulSoup(data_g1.text, 'html.parser')
    data_ge = requests.get('https://ge.globo.com/')
    soup_ge = BeautifulSoup(data_ge.text, 'html.parser')

    g1_scrapped_data = {
        'full_content': [span.text for span in soup_g1.find_all('div', {'class': 'feed-post-body'})],
        'headers':[span.text for span in soup_g1.find_all('div', {'class': 'feed-post-header with-post-chapeu'})],
        'title':[span.text for span in soup_g1.find_all('div', {'class': 'feed-post-body-title '
                                                                         'gui-color-primary gui-color-hover'})],
        'review':[span.text for span in soup_g1.find_all('div', {'class': 'feed-post-body-resumo'})],
        'related':[span.text for span in soup_g1.find_all('div', {'class': 'bstn-fd-relatedtext'})],
        'feed_time':[span.text for span in soup_g1.find_all('div', {'class': 'feed-post-metadata'})],
        'scrapdate': timezone.now()
    }

    ge_scrapped_data = {
        'full_content': [span.text for span in soup_ge.find_all('div', {'class': 'feed-post-body'})],
        'headers': [span.text for span in soup_ge.find_all('div', {'class': 'feed-post-header with-post-chapeu'})],
        'title': [span.text for span in soup_ge.find_all('div', {'class': 'feed-post-body-title '
                                                                             'gui-color-primary gui-color-hover'})],
        'review': [span.text for span in soup_ge.find_all('div', {'class': 'feed-post-body-resumo'})],
        'related': [span.text for span in soup_ge.find_all('div', {'class': 'bstn-fd-relatedtext'})],
        'feed_time': [span.text for span in soup_ge.find_all('div', {'class': 'feed-post-metadata'})],
        'scrapdate': timezone.now()
    }
    return g1_scrapped_data, ge_scrapped_data
