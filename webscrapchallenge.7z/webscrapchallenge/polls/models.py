from django.db import models
from django.utils import timezone
import datetime

class G1(models.Model):
    title = models.CharField(max_length=200)
    subtitle = models.CharField(max_lenght=300)
    scrap_time = models.DateTimeField('date scrapped')

    def __str__(self):
        return {'title':self.title,'subtitle':self.subtitle}

class GE(models.Model):
    title = models.CharField(max_length=200)
    subtitle = models.CharField(max_lenght=300)
    scrap_time = models.DateTimeField('date scrapped')

    def __str__(self):
        return {'title':self.title,'subtitle':self.subtitle}

class ScrappedData(models.Model):
    data_g1 = models.ForeignKey(G1, on_delete=models.CASCADE)
    data_ge = models.ForeignKey(GE, on_delete=models.CASCADE)
# Create your models here.
